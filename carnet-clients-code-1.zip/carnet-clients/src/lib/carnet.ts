import { useSyncExternalStore } from "react";

export type FieldType = "text" | "number" | "date" | "phone" | "check" | "note";

export type Field = {
  id: string;
  label: string;
  type: FieldType;
  builtin: boolean;
};

export type Client = {
  id: string;
  createdAt: number;
  values: Record<string, string>;
};

export type ViewPref = "auto" | "cards" | "table";

export type Data = {
  fields: Field[];
  clients: Client[];
  viewPref: ViewPref;
};

export type FilterId = "all" | "late" | "week";

export type DueKind =
  | { kind: "empty" }
  | { kind: "bad"; label: string }
  | { kind: "late"; days: number; label: string }
  | { kind: "today"; label: string }
  | { kind: "soon"; days: number; label: string }
  | { kind: "later"; label: string };

export const FIELD_TYPE_LABEL: Record<FieldType, string> = {
  text: "Texte",
  number: "Nombre",
  date: "Date",
  phone: "Téléphone",
  check: "Oui / Non",
  note: "Note",
};

const FIELD_TYPES = new Set<FieldType>(["text", "number", "date", "phone", "check", "note"]);

const MONTHS = [
  "janv.",
  "févr.",
  "mars",
  "avr.",
  "mai",
  "juin",
  "juil.",
  "août",
  "sept.",
  "oct.",
  "nov.",
  "déc.",
];

const BUILTIN_FIELDS: Field[] = [
  { id: "nom", label: "Nom", type: "text", builtin: true },
  { id: "prenom", label: "Prénom", type: "text", builtin: true },
  { id: "telephone", label: "Téléphone", type: "phone", builtin: true },
  { id: "adresse", label: "Adresse", type: "text", builtin: true },
  { id: "echeance", label: "Date d'échéance", type: "date", builtin: true },
];

const STORAGE_KEY = "carnet-clients-v1";

const INITIAL: Data = {
  fields: BUILTIN_FIELDS,
  clients: [],
  viewPref: "auto",
};

let data: Data = INITIAL;
let hydrated = false;
const listeners = new Set<() => void>();

function emit() {
  for (const listener of listeners) listener();
}

function persist() {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    // Quota or private mode: keep the session in memory.
  }
}

export function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getData() {
  return data;
}

export function getServerSnapshot() {
  return INITIAL;
}

export function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  const stored = readStorage();
  if (stored) data = stored;
  emit();
}

function update(mutator: (current: Data) => Data) {
  if (!hydrated) hydrate();
  data = mutator(data);
  persist();
  emit();
}

export function useCarnet() {
  return useSyncExternalStore(subscribe, getData, getServerSnapshot);
}

export function todayIsoLocal() {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

export function clientTitle(values: Record<string, string>) {
  const name = `${values.prenom ?? ""} ${values.nom ?? ""}`.replace(/\s+/g, " ").trim();
  return name || "Sans nom";
}

export function telHref(phone: string) {
  const digits = phone.replace(/[^\d+]/g, "");
  if (digits.replace(/\D/g, "").length < 6) return null;
  return `tel:${digits}`;
}

export function dueInfo(raw: string, todayIso: string | null): DueKind {
  const value = raw.trim();
  if (!value) return { kind: "empty" };
  const iso = toIsoDate(value);
  if (!iso) return { kind: "bad", label: value };
  const label = formatFrenchDate(iso);
  if (!todayIso) return { kind: "later", label };
  const diff = utcDay(iso) - utcDay(todayIso);
  if (diff < 0) return { kind: "late", days: -diff, label };
  if (diff === 0) return { kind: "today", label };
  if (diff <= 7) return { kind: "soon", days: diff, label };
  return { kind: "later", label };
}

export function dueLabel(info: DueKind) {
  switch (info.kind) {
    case "empty":
      return "Sans échéance";
    case "bad":
      return info.label;
    case "late":
      return info.days === 1 ? "En retard · 1 jour" : `En retard · ${info.days} jours`;
    case "today":
      return "Aujourd'hui";
    case "soon":
      return info.days === 1 ? "Demain" : `Dans ${info.days} jours`;
    case "later":
      return info.label;
  }
}

export function formatFieldValue(field: Field, value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "";
  if (field.type === "check") return trimmed === "1" ? "Oui" : "Non";
  if (field.type === "date") {
    const iso = toIsoDate(trimmed);
    return iso ? formatFrenchDate(iso) : trimmed;
  }
  if (field.type === "number") {
    const n = Number(trimmed.replace(/\s/g, "").replace(",", "."));
    if (!Number.isFinite(n)) return trimmed;
    return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 2 }).format(n);
  }
  return trimmed;
}

export function compareClients(
  a: Client,
  b: Client,
  field: Field | undefined,
  dir: "asc" | "desc",
) {
  if (!field) return 0;
  const va = (a.values[field.id] ?? "").trim();
  const vb = (b.values[field.id] ?? "").trim();
  if (!va && !vb) return a.createdAt - b.createdAt;
  if (!va) return 1;
  if (!vb) return -1;
  let cmp = 0;
  if (field.type === "number") {
    const na = Number(va.replace(/\s/g, "").replace(",", ".")) || 0;
    const nb = Number(vb.replace(/\s/g, "").replace(",", ".")) || 0;
    cmp = na - nb;
  } else if (field.type === "date") {
    cmp = (toIsoDate(va) ?? va).localeCompare(toIsoDate(vb) ?? vb);
  } else {
    cmp = va.localeCompare(vb, "fr", { sensitivity: "base", numeric: true });
  }
  if (cmp === 0) cmp = clientTitle(a.values).localeCompare(clientTitle(b.values), "fr");
  return dir === "asc" ? cmp : -cmp;
}

export function addClient(values: Record<string, string>) {
  const client: Client = { id: uid(), createdAt: Date.now(), values: cleanValues(values) };
  update((current) => ({ ...current, clients: [client, ...current.clients] }));
  return client.id;
}

export function updateClient(id: string, values: Record<string, string>) {
  update((current) => ({
    ...current,
    clients: current.clients.map((client) =>
      client.id === id ? { ...client, values: cleanValues(values) } : client,
    ),
  }));
}

export function removeClient(id: string) {
  update((current) => ({
    ...current,
    clients: current.clients.filter((client) => client.id !== id),
  }));
}

export function duplicateClient(id: string) {
  let copyId = "";
  update((current) => {
    const source = current.clients.find((client) => client.id === id);
    if (!source) return current;
    copyId = uid();
    const copy: Client = {
      id: copyId,
      createdAt: Date.now(),
      values: { ...source.values },
    };
    return { ...current, clients: [copy, ...current.clients] };
  });
  return copyId;
}

export function clearClients() {
  update((current) => ({ ...current, clients: [] }));
}

export function setViewPref(viewPref: ViewPref) {
  update((current) => ({ ...current, viewPref }));
}

export function addField(label: string, type: FieldType) {
  const clean = clipLabel(label);
  if (!clean || !FIELD_TYPES.has(type)) return;
  update((current) => ({
    ...current,
    fields: [...current.fields, { id: makeFieldId(clean), label: clean, type, builtin: false }],
  }));
}

export function renameField(id: string, label: string) {
  const clean = clipLabel(label);
  if (!clean) return;
  update((current) => ({
    ...current,
    fields: current.fields.map((field) => (field.id === id ? { ...field, label: clean } : field)),
  }));
}

export function removeField(id: string) {
  update((current) => {
    const field = current.fields.find((item) => item.id === id);
    if (!field || field.builtin) return current;
    return {
      ...current,
      fields: current.fields.filter((item) => item.id !== id),
      clients: current.clients.map((client) => {
        if (!(id in client.values)) return client;
        const values = { ...client.values };
        delete values[id];
        return { ...client, values };
      }),
    };
  });
}

export function moveField(id: string, direction: -1 | 1) {
  update((current) => {
    const index = current.fields.findIndex((field) => field.id === id);
    const next = index + direction;
    if (index < 0 || next < 0 || next >= current.fields.length) return current;
    const fields = [...current.fields];
    const [item] = fields.splice(index, 1);
    fields.splice(next, 0, item);
    return { ...current, fields };
  });
}

export function loadExamples() {
  const today = todayIsoLocal();
  let added = 0;
  update((current) => {
    const fields = [...current.fields];
    const emailId = ensureField(fields, "Email", "text");
    const amountId = ensureField(fields, "Montant dû", "number");
    const samples = exampleRows(today, emailId, amountId);
    const clients = [...current.clients];
    for (const values of samples) {
      clients.unshift({ id: uid(), createdAt: Date.now(), values });
      added += 1;
    }
    return { ...current, fields, clients };
  });
  return added;
}

export function exportCsv(fields: Field[], clients: Client[]) {
  const lines = [
    "sep=;",
    fields.map((field) => csvCell(field.label)).join(";"),
    ...clients.map((client) =>
      fields
        .map((field) => csvCell(exportCell(field, client.values[field.id] ?? "")))
        .join(";"),
    ),
  ];
  return `\uFEFF${lines.join("\r\n")}`;
}

export function importCsv(text: string) {
  const table = parseCsv(text);
  if (table.length === 0) return { added: 0, columns: 0, error: "Le fichier est vide." };
  let rows = table;
  if (/^sep=/i.test(rows[0]?.[0]?.trim() ?? "")) rows = rows.slice(1);
  if (rows.length === 0) return { added: 0, columns: 0, error: "Aucune ligne à lire." };
  const headers = rows[0].map((header) => header.trim());
  if (headers.every((header) => !header)) {
    return { added: 0, columns: 0, error: "La première ligne doit contenir les noms de colonnes." };
  }
  const body = rows.slice(1).slice(0, 5000);
  let added = 0;
  let columns = 0;
  update((current) => {
    const fields = [...current.fields];
    const ids = headers.map((header) => {
      if (!header) return null;
      const existing = fields.find((field) => normalizeLabel(field.label) === normalizeLabel(header));
      if (existing) return existing.id;
      const type = guessType(header);
      const field: Field = { id: makeFieldId(header), label: clipLabel(header), type, builtin: false };
      fields.push(field);
      columns += 1;
      return field.id;
    });
    const clients = [...current.clients];
    for (const row of body) {
      const values: Record<string, string> = {};
      ids.forEach((id, index) => {
        if (!id) return;
        const field = fields.find((item) => item.id === id);
        if (!field) return;
        const coerced = coerceImported(field, row[index] ?? "");
        if (coerced) values[id] = coerced;
      });
      if (Object.keys(values).length === 0) continue;
      clients.unshift({ id: uid(), createdAt: Date.now(), values });
      added += 1;
    }
    return { ...current, fields, clients };
  });
  return { added, columns, error: added === 0 ? "Aucune ligne de client reconnue." : undefined };
}

function exampleRows(today: string, emailId: string, amountId: string) {
  const row = (
    nom: string,
    prenom: string,
    telephone: string,
    adresse: string,
    dayOffset: number | null,
    email: string,
    amount: string,
  ) => ({
    nom,
    prenom,
    telephone,
    adresse,
    echeance: dayOffset === null ? "" : addIsoDays(today, dayOffset),
    [emailId]: email,
    [amountId]: amount,
  });
  return [
    row("Martin", "Claire", "06 18 42 77 03", "14 rue des Lilas, Lyon", -6, "claire.martin@example.com", "240"),
    row("Benali", "Karim", "07 61 20 88 45", "8 avenue Jean Jaurès, Marseille", 2, "karim.benali@example.com", "180"),
    row("Bernard", "Sophie", "06 45 90 12 33", "22 place du Capitole, Toulouse", 0, "sophie.bernard@example.com", "90"),
    row("Rossi", "Antoine", "04 78 11 26 90", "3 quai de la Fosse, Nantes", 18, "antoine.rossi@example.com", "420"),
    row("El Khattabi", "Nadia", "06 22 71 08 56", "101 rue Nationale, Lille", null, "nadia.elk@example.com", ""),
    row("Petit", "Hugo", "07 80 14 63 29", "5 cours de l'Intendance, Bordeaux", -1, "hugo.petit@example.com", "75"),
  ];
}

function ensureField(fields: Field[], label: string, type: FieldType) {
  const existing = fields.find((field) => normalizeLabel(field.label) === normalizeLabel(label));
  if (existing) return existing.id;
  const id = makeFieldId(label);
  fields.push({ id, label, type, builtin: false });
  return id;
}

function readStorage(): Data | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return normalize(JSON.parse(raw) as Partial<Data>);
  } catch {
    return null;
  }
}

function normalize(input: Partial<Data> | null): Data {
  const rawFields = Array.isArray(input?.fields) ? input.fields : [];
  const fields: Field[] = [];
  const seen = new Set<string>();
  for (const field of rawFields) {
    if (!field || typeof field.id !== "string" || seen.has(field.id)) continue;
    const builtin = BUILTIN_FIELDS.find((item) => item.id === field.id);
    if (builtin) {
      fields.push({
        id: builtin.id,
        label: clipLabel(typeof field.label === "string" ? field.label : "") || builtin.label,
        type: builtin.type,
        builtin: true,
      });
      seen.add(field.id);
      continue;
    }
    if (!isFieldType(field.type) || typeof field.label !== "string") continue;
    const label = clipLabel(field.label);
    if (!label) continue;
    fields.push({ id: field.id, label, type: field.type, builtin: false });
    seen.add(field.id);
  }
  BUILTIN_FIELDS.forEach((builtin, index) => {
    if (seen.has(builtin.id)) return;
    fields.splice(Math.min(index, fields.length), 0, { ...builtin });
  });

  const clients: Client[] = [];
  if (Array.isArray(input?.clients)) {
    for (const client of input.clients) {
      if (!client || typeof client.id !== "string") continue;
      const values: Record<string, string> = {};
      if (client.values && typeof client.values === "object") {
        for (const [key, value] of Object.entries(client.values)) {
          if (typeof value === "string") values[key] = value;
          else if (typeof value === "number" || typeof value === "boolean") values[key] = String(value);
        }
      }
      clients.push({
        id: client.id,
        createdAt: typeof client.createdAt === "number" ? client.createdAt : 0,
        values,
      });
    }
  }

  const viewPref: ViewPref =
    input?.viewPref === "cards" || input?.viewPref === "table" || input?.viewPref === "auto"
      ? input.viewPref
      : "auto";

  return { fields, clients, viewPref };
}

function cleanValues(values: Record<string, string>) {
  const next: Record<string, string> = {};
  for (const [key, value] of Object.entries(values)) {
    if (typeof value !== "string") continue;
    const trimmed = value.trim();
    if (trimmed) next[key] = trimmed;
  }
  return next;
}

function isFieldType(value: unknown): value is FieldType {
  return typeof value === "string" && FIELD_TYPES.has(value as FieldType);
}

function clipLabel(label: string) {
  return label.replace(/\s+/g, " ").trim().slice(0, 60);
}

function normalizeLabel(label: string) {
  return label
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function makeFieldId(label: string) {
  const slug = normalizeLabel(label).replace(/\s+/g, "-").slice(0, 24) || "champ";
  return `c_${slug}_${Math.random().toString(36).slice(2, 7)}`;
}

function uid() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `id_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function guessType(header: string): FieldType {
  const name = normalizeLabel(header);
  if (/(date|echeance|echeances)/.test(name)) return "date";
  if (/(tel|telephone|mobile|portable)/.test(name)) return "phone";
  if (/(montant|prix|somme|du |impaye)/.test(name)) return "number";
  if (/(note|commentaire|remarque)/.test(name)) return "note";
  return "text";
}

function coerceImported(field: Field, raw: string) {
  const value = raw.trim();
  if (!value) return "";
  if (field.type === "date") return toIsoDate(value) ?? value;
  if (field.type === "check") return /^(oui|yes|true|1|x|vrai)$/i.test(value) ? "1" : "";
  return value;
}

function exportCell(field: Field, value: string) {
  if (!value) return "";
  if (field.type === "date") {
    const iso = toIsoDate(value);
    if (!iso) return value;
    const [year, month, day] = iso.split("-");
    return `${day}/${month}/${year}`;
  }
  if (field.type === "check") return value === "1" ? "Oui" : "";
  return value;
}

function csvCell(value: string) {
  let safe = value ?? "";
  if (/^[=+\-@\t\r]/.test(safe)) safe = `'${safe}`;
  if (/[";\n\r]/.test(safe)) return `"${safe.replace(/"/g, '""')}"`;
  return safe;
}

export function parseCsv(text: string) {
  const cleaned = text.replace(/^\uFEFF/, "");
  const sample = cleaned.split(/\r?\n/, 1)[0] ?? "";
  const semis = sample.match(/;/g)?.length ?? 0;
  const commas = sample.match(/,/g)?.length ?? 0;
  const sep = semis >= commas ? ";" : ",";
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < cleaned.length; i += 1) {
    const ch = cleaned[i];
    if (quoted) {
      if (ch === '"') {
        if (cleaned[i + 1] === '"') {
          cell += '"';
          i += 1;
        } else {
          quoted = false;
        }
      } else {
        cell += ch;
      }
      continue;
    }
    if (ch === '"') {
      quoted = true;
    } else if (ch === sep) {
      row.push(cell);
      cell = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && cleaned[i + 1] === "\n") i += 1;
      row.push(cell);
      cell = "";
      if (row.some((item) => item.trim() !== "")) rows.push(row);
      row = [];
    } else {
      cell += ch;
    }
  }
  row.push(cell);
  if (row.some((item) => item.trim() !== "")) rows.push(row);
  return rows;
}

function toIsoDate(raw: string) {
  const value = raw.trim();
  const iso = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (iso) {
    return validYmd(Number(iso[1]), Number(iso[2]), Number(iso[3]))
      ? `${iso[1]}-${iso[2]}-${iso[3]}`
      : null;
  }
  const local = /^(\d{1,2})[/. -](\d{1,2})[/. -](\d{4})$/.exec(value);
  if (!local) return null;
  const day = local[1].padStart(2, "0");
  const month = local[2].padStart(2, "0");
  const year = local[3];
  return validYmd(Number(year), Number(month), Number(day)) ? `${year}-${month}-${day}` : null;
}

function validYmd(year: number, month: number, day: number) {
  if (month < 1 || month > 12 || day < 1 || day > 31) return false;
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

function formatFrenchDate(iso: string) {
  const [, month, day] = iso.split("-");
  const year = iso.slice(0, 4);
  return `${Number(day)} ${MONTHS[Number(month) - 1]} ${year}`;
}

function utcDay(iso: string) {
  const [year, month, day] = iso.split("-").map(Number);
  return Math.floor(Date.UTC(year, month - 1, day) / 86_400_000);
}

function addIsoDays(iso: string, days: number) {
  const [year, month, day] = iso.split("-").map(Number);
  const date = new Date(Date.UTC(year, month - 1, day + days));
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, "0");
  const d = String(date.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}
