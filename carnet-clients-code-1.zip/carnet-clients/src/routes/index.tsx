import { createFileRoute } from "@tanstack/react-router";
import { CarnetApp } from "@/components/carnet-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <CarnetApp />;
}
