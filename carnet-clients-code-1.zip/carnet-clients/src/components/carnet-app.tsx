import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import * as AlertDialog from "@radix-ui/react-alert-dialog";
import * as DropdownMenu from "@radix-ui/react-dropdown-menu";
import { Drawer } from "vaul";
import {
  CalendarClock,
  ChevronDown,
  ChevronUp,
  Columns3,
  Download,
  LayoutGrid,
  MapPin,
  Menu,
  Pencil,
  Phone,
  Plus,
  Search,
  Smartphone,
  Table2,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { cn } from "@/lib/cn";
import {
  addClient,
  addField,
  clearClients,
  clientTitle,
  compareClients,
  dueInfo,
  dueLabel,
  duplicateClient,
  exportCsv,
  FIELD_TYPE_LABEL,
  formatFieldValue,
  hydrate,
  importCsv,
  loadExamples,
  moveField,
  removeClient,
  removeField,
  renameField,
  setViewPref,
  telHref,
  todayIsoLocal,
  updateClient,
  useCarnet,
  getData,
  type Client,
  type DueKind,
  type Field,
  type FieldType,
  type FilterId,
} from "@/lib/carnet";

type ConfirmState = {
  title: string;
  body: string;
  confirmLabel: string;
  run: () => void;
};

const TYPES: FieldType[] = ["text", "number", "date", "phone", "check", "note"];

function isCarnetApk() {
  return typeof window !== "undefined" && window.__CARNET_APK__ === true;
}

declare global {
  interface Window {
    __CARNET_APK__?: boolean;
    __carnetOnBack?: () => boolean;
    CarnetAndroid?: { saveText: (filename: string, content: string) => void };
  }
}

export function CarnetApp() {
  const data = useCarnet();
  const fileRef = useRef<HTMLInputElement>(null);
  const [today, setToday] = useState<string | null>(null);
  const [wide, setWide] = useState(false);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterId>("all");
  const [sort, setSort] = useState<{ id: string; dir: "asc" | "desc" }>({ id: "echeance", dir: "asc" });
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [formError, setFormError] = useState("");
  const [columnsOpen, setColumnsOpen] = useState(false);
  const [newLabel, setNewLabel] = useState("");
  const [newType, setNewType] = useState<FieldType>("text");
  const [labelDraft, setLabelDraft] = useState<Record<string, string>>({});
  const [confirm, setConfirm] = useState<ConfirmState | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [showInstall, setShowInstall] = useState(() => !isCarnetApk());

  useEffect(() => {
    hydrate();
    setToday(todayIsoLocal());
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in navigator && Boolean((navigator as Navigator & { standalone?: boolean }).standalone));
    if (isCarnetApk() || standalone || localStorage.getItem("carnet-install-dismissed") === "1") setShowInstall(false);
    const media = window.matchMedia("(min-width: 1024px)");
    const apply = () => setWide(media.matches);
    apply();
    media.addEventListener("change", apply);
    return () => media.removeEventListener("change", apply);
  }, []);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 4200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    window.__carnetOnBack = () => {
      if (formOpen) {
        setFormOpen(false);
        return true;
      }
      if (columnsOpen) {
        setColumnsOpen(false);
        return true;
      }
      if (confirm) {
        setConfirm(null);
        return true;
      }
      return false;
    };
    return () => {
      delete window.__carnetOnBack;
    };
  }, [formOpen, columnsOpen, confirm]);

  const activeView = data.viewPref === "auto" ? (wide ? "table" : "cards") : data.viewPref;
  const sortField = data.fields.find((field) => field.id === sort.id) ?? data.fields.find((field) => field.id === "echeance");
  const needle = query.trim().toLowerCase();
  const visible = data.clients
    .filter((client) => {
      if (needle) {
        const hay = Object.values(client.values).join(" ").toLowerCase();
        if (!hay.includes(needle)) return false;
      }
      if (filter === "all") return true;
      const kind = dueInfo(client.values.echeance ?? "", today).kind;
      if (filter === "late") return kind === "late";
      return kind === "today" || kind === "soon";
    })
    .sort((a, b) => compareClients(a, b, sortField, sort.dir));

  const counts = {
    all: data.clients.length,
    late: data.clients.filter((client) => dueInfo(client.values.echeance ?? "", today).kind === "late").length,
    week: data.clients.filter((client) => {
      const kind = dueInfo(client.values.echeance ?? "", today).kind;
      return kind === "today" || kind === "soon";
    }).length,
  };

  function openCreate() {
    setEditingId(null);
    setDraft({});
    setFormError("");
    setFormOpen(true);
  }

  function openEdit(client: Client) {
    setEditingId(client.id);
    setDraft({ ...client.values });
    setFormError("");
    setFormOpen(true);
  }

  function saveClient(event: FormEvent) {
    event.preventDefault();
    const values: Record<string, string> = {};
    for (const field of data.fields) {
      const value = (draft[field.id] ?? "").trim();
      if (value) values[field.id] = value;
    }
    if (Object.keys(values).length === 0) {
      setFormError("Renseignez au moins un champ.");
      return;
    }
    if (editingId) updateClient(editingId, values);
    else addClient(values);
    setFormOpen(false);
    setNotice(editingId ? "Client modifié." : "Client ajouté.");
  }

  function askDelete(client: Client) {
    setConfirm({
      title: `Supprimer ${clientTitle(client.values)} ?`,
      body: "Cette fiche disparaît de cet appareil. Exportez le carnet avant si vous voulez une copie.",
      confirmLabel: "Supprimer",
      run: () => {
        removeClient(client.id);
        if (editingId === client.id) setFormOpen(false);
        setNotice("Client supprimé.");
      },
    });
  }

  function onExport(template: boolean) {
    const rows = template ? [] : visible;
    if (!template && rows.length === 0) {
      setNotice("Rien à exporter avec ce filtre.");
      return;
    }
    const csv = exportCsv(data.fields, rows);
    const name = template ? "modele-carnet-clients.csv" : `carnet-clients-${todayIsoLocal()}.csv`;
    downloadText(name, csv);
    setNotice(template ? "Modèle téléchargé. Ouvrez-le dans Excel, puis réimportez-le." : `${rows.length} ligne${rows.length > 1 ? "s" : ""} exportée${rows.length > 1 ? "s" : ""}.`);
  }

  async function onImport(file: File) {
    const text = await file.text();
    const result = importCsv(text);
    if (result.error && result.added === 0) setNotice(result.error);
    else {
      const extra = result.columns ? ` ${result.columns} colonne${result.columns > 1 ? "s" : ""} ajoutée${result.columns > 1 ? "s" : ""}.` : "";
      setNotice(`${result.added} client${result.added > 1 ? "s" : ""} importé${result.added > 1 ? "s" : ""}.${extra}`);
    }
  }

  function addColumn(event: FormEvent) {
    event.preventDefault();
    const label = newLabel.trim();
    if (!label) return;
    addField(label, newType);
    setNewLabel("");
    setNotice(`Colonne « ${label} » ajoutée.`);
  }

  function toggleSort(id: string) {
    setSort((current) =>
      current.id === id ? { id, dir: current.dir === "asc" ? "desc" : "asc" } : { id, dir: "asc" },
    );
  }

  const grouped = sort.id === "echeance" && sort.dir === "asc";

  return (
    <div className="min-h-dvh bg-bg text-ink">
      <header className="pt-safe bg-primary text-primary-fg">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 pb-5">
          <div className="min-w-0">
            <h1 className="font-display text-4xl leading-none tracking-tight">Carnet</h1>
            <p className="mt-1 text-sm text-primary-fg/80">
              {data.clients.length === 1 ? "1 client" : `${data.clients.length} clients`} · enregistré sur cet appareil
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <button type="button" onClick={openCreate} className={cn(btnInverse, "hidden lg:inline-flex")}>
              <Plus className="size-4" />
              Nouveau client
            </button>
            <DropdownMenu.Root>
              <DropdownMenu.Trigger asChild>
                <button type="button" className={iconInverse} aria-label="Plus d'actions">
                  <Menu className="size-5" />
                </button>
              </DropdownMenu.Trigger>
              <DropdownMenu.Portal>
                <DropdownMenu.Content
                  align="end"
                  sideOffset={8}
                  className="z-50 w-64 rounded-2xl border border-line bg-surface p-1 text-ink shadow-lg"
                >
                  <MenuItem onSelect={() => fileRef.current?.click()}>
                    <Upload className="size-4" /> Importer un CSV
                  </MenuItem>
                  <MenuItem onSelect={() => onExport(false)}>
                    <Download className="size-4" /> Exporter vers Excel
                  </MenuItem>
                  <MenuItem onSelect={() => onExport(true)}>
                    <Download className="size-4" /> Télécharger le modèle
                  </MenuItem>
                  <MenuItem onSelect={() => setColumnsOpen(true)}>
                    <Columns3 className="size-4" /> Gérer les colonnes
                  </MenuItem>
                  <MenuItem
                    onSelect={() => {
                      const added = loadExamples();
                      setNotice(`${added} clients d'exemple ajoutés.`);
                    }}
                  >
                    <Plus className="size-4" /> Ajouter des exemples
                  </MenuItem>
                  <DropdownMenu.Separator className="my-1 h-px bg-line" />
                  <MenuItem
                    onSelect={() =>
                      setConfirm({
                        title: "Effacer tous les clients ?",
                        body: "Les colonnes que vous avez ajoutées sont conservées. Les fiches, elles, sont supprimées de cet appareil.",
                        confirmLabel: "Tout effacer",
                        run: () => {
                          clearClients();
                          setNotice("Carnet vidé.");
                        },
                      })
                    }
                  >
                    <Trash2 className="size-4" /> Tout effacer
                  </MenuItem>
                </DropdownMenu.Content>
              </DropdownMenu.Portal>
            </DropdownMenu.Root>
          </div>
        </div>
      </header>

      <main className="pb-bar mx-auto flex w-full min-w-0 max-w-6xl flex-col gap-4 px-4 py-4">
        {showInstall && (
          <div className="flex items-start gap-3 rounded-2xl border border-line bg-surface px-4 py-3">
            <Smartphone className="mt-0.5 size-5 shrink-0 text-primary" />
            <p className="min-w-0 flex-1 text-sm text-pretty">
              Android : menu du navigateur, puis « Ajouter à l'écran d'accueil ».
            </p>
            <button
              type="button"
              className={iconGhost}
              aria-label="Masquer l'aide d'installation"
              onClick={() => {
                localStorage.setItem("carnet-install-dismissed", "1");
                setShowInstall(false);
              }}
            >
              <X className="size-4" />
            </button>
          </div>
        )}

        {notice && (
          <p role="status" className="rounded-2xl bg-primary/10 px-4 py-3 text-sm font-medium text-primary">
            {notice}
          </p>
        )}

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <label className="relative block min-w-0 flex-1">
            <span className="sr-only">Rechercher un client</span>
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Nom, téléphone, adresse…"
              className={cn(inputClass, "pl-10")}
            />
          </label>
          <div className="flex shrink-0 gap-2" role="group" aria-label="Mode d'affichage">
            <button
              type="button"
              className={cn(viewBtn, activeView === "cards" && viewBtnOn)}
              aria-pressed={activeView === "cards"}
              onClick={() => setViewPref("cards")}
            >
              <LayoutGrid className="size-4" />
              Cartes
            </button>
            <button
              type="button"
              className={cn(viewBtn, activeView === "table" && viewBtnOn)}
              aria-pressed={activeView === "table"}
              onClick={() => setViewPref("table")}
            >
              <Table2 className="size-4" />
              Tableau
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          <StatChip label="Clients" count={counts.all} active={filter === "all"} onClick={() => setFilter("all")} />
          <StatChip label="En retard" count={counts.late} active={filter === "late"} tone="danger" onClick={() => setFilter("late")} />
          <StatChip label="7 jours" count={counts.week} active={filter === "week"} tone="warn" onClick={() => setFilter("week")} />
        </div>

        <section className={cn(data.viewPref === "auto" && "lg:hidden", data.viewPref === "table" && "hidden")}>
          {data.clients.length === 0 ? (
            <EmptyState onCreate={openCreate} onExamples={() => setNotice(`${loadExamples()} clients d'exemple ajoutés.`)} onImport={() => fileRef.current?.click()} />
          ) : visible.length === 0 ? (
            <NoResults onReset={() => { setQuery(""); setFilter("all"); }} />
          ) : grouped ? (
            <div className="flex flex-col gap-6">
              <ClientGroup title="En retard" clients={visible.filter((client) => bucket(client, today) === "late")} fields={data.fields} today={today} onEdit={openEdit} onDelete={askDelete} />
              <ClientGroup title="Dans les 7 jours" clients={visible.filter((client) => bucket(client, today) === "week")} fields={data.fields} today={today} onEdit={openEdit} onDelete={askDelete} />
              <ClientGroup title="Plus tard" clients={visible.filter((client) => bucket(client, today) === "later")} fields={data.fields} today={today} onEdit={openEdit} onDelete={askDelete} />
              <ClientGroup title="Sans échéance" clients={visible.filter((client) => bucket(client, today) === "empty")} fields={data.fields} today={today} onEdit={openEdit} onDelete={askDelete} />
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {visible.map((client) => (
                <ClientCard key={client.id} client={client} fields={data.fields} today={today} onEdit={openEdit} onDelete={askDelete} />
              ))}
            </div>
          )}
        </section>

        <section className={cn("min-w-0", data.viewPref === "auto" && "hidden lg:block", data.viewPref === "cards" && "hidden")}>
          <div className="max-w-full overflow-x-auto rounded-2xl border border-line bg-surface">
            <table className="w-full border-collapse text-left text-sm">
              <caption className="sr-only">Tableau des clients</caption>
              <thead className="bg-surface-2 text-muted">
                <tr>
                  {data.fields.map((field) => {
                    const active = sortField?.id === field.id;
                    return (
                      <th key={field.id} scope="col" className="min-w-36 px-3 py-3 font-medium" aria-sort={active ? (sort.dir === "asc" ? "ascending" : "descending") : "none"}>
                        <button type="button" className="inline-flex items-center gap-1 text-left" onClick={() => toggleSort(field.id)}>
                          {field.label}
                          {active && (sort.dir === "asc" ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />)}
                        </button>
                      </th>
                    );
                  })}
                  <th scope="col" className="w-28 px-3 py-3">
                    <span className="sr-only">Actions</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {visible.length === 0 ? (
                  <tr>
                    <td colSpan={data.fields.length + 1} className="px-4 py-14 text-center">
                      {data.clients.length === 0 ? (
                        <EmptyState compact onCreate={openCreate} onExamples={() => setNotice(`${loadExamples()} clients d'exemple ajoutés.`)} onImport={() => fileRef.current?.click()} />
                      ) : (
                        <NoResults onReset={() => { setQuery(""); setFilter("all"); }} />
                      )}
                    </td>
                  </tr>
                ) : (
                  visible.map((client) => {
                    const info = dueInfo(client.values.echeance ?? "", today);
                    return (
                      <tr key={client.id} className="border-t border-line align-top">
                        {data.fields.map((field) => (
                          <td key={field.id} className="max-w-64 px-3 py-3 break-words">
                            {field.id === "echeance" ? (
                              <DueText info={info} />
                            ) : field.type === "phone" && telHref(client.values[field.id] ?? "") ? (
                              <a className="font-medium text-primary" href={telHref(client.values[field.id] ?? "") ?? undefined}>
                                {client.values[field.id]}
                              </a>
                            ) : (
                              <span className={field.type === "number" ? "tabular-nums" : undefined}>
                                {formatFieldValue(field, client.values[field.id] ?? "") || "—"}
                              </span>
                            )}
                          </td>
                        ))}
                        <td className="px-2 py-2">
                          <div className="flex justify-end">
                            <button type="button" className={iconGhost} aria-label={`Modifier ${clientTitle(client.values)}`} onClick={() => openEdit(client)}>
                              <Pencil className="size-4" />
                            </button>
                            <button type="button" className={iconGhost} aria-label={`Supprimer ${clientTitle(client.values)}`} onClick={() => askDelete(client)}>
                              <Trash2 className="size-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
          <p className="mt-2 text-sm text-muted">
            Cliquez un en-tête pour trier. Les colonnes en plus se gèrent comme dans un tableur.
          </p>
        </section>
      </main>

      <div className="bar-safe fixed inset-x-0 bottom-0 z-30 grid grid-cols-2 gap-2 border-t border-line bg-surface px-3 pt-2 lg:hidden">
        <button type="button" className={btnSurface} onClick={() => setColumnsOpen(true)}>
          <Columns3 className="size-4" />
          Colonnes
        </button>
        <button type="button" className={btnPrimary} onClick={openCreate}>
          <Plus className="size-4" />
          Nouveau client
        </button>
      </div>

      <input
        ref={fileRef}
        type="file"
        accept=".csv,text/csv,text/plain"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          event.target.value = "";
          if (file) void onImport(file);
        }}
      />

      <Sheet
        open={formOpen}
        onOpenChange={setFormOpen}
        title={editingId ? "Modifier le client" : "Nouveau client"}
        description="Nom, prénom, téléphone, adresse, échéance — et vos colonnes."
        footer={
          <div className="flex flex-wrap gap-2">
            {editingId && (
              <button
                type="button"
                className={btnSurface}
                onClick={() => {
                  const id = duplicateClient(editingId);
                  const source = getData().clients.find((client) => client.id === id);
                  if (source) {
                    setEditingId(id);
                    setDraft({ ...source.values });
                    setNotice("Copie créée. Vous modifiez la nouvelle fiche.");
                  }
                }}
              >
                Dupliquer
              </button>
            )}
            {editingId && (
              <button
                type="button"
                className={cn(btnSurface, "text-danger")}
                onClick={() => {
                  const client = getData().clients.find((item) => item.id === editingId);
                  if (client) askDelete(client);
                }}
              >
                Supprimer
              </button>
            )}
            <button type="submit" form="client-form" className={cn(btnPrimary, "ml-auto min-w-36")}>
              Enregistrer
            </button>
          </div>
        }
      >
        <form id="client-form" onSubmit={saveClient} className="flex flex-col gap-4 px-5 py-4">
          {data.fields.map((field) => (
            <label key={field.id} className="block">
              <span className="mb-1 block text-sm font-medium">{field.label}</span>
              <FieldControl
                field={field}
                value={draft[field.id] ?? ""}
                autoFocus={field.id === "nom"}
                onChange={(value) => setDraft((current) => ({ ...current, [field.id]: value }))}
              />
            </label>
          ))}
          {formError && (
            <p role="alert" className="text-sm font-medium text-danger">
              {formError}
            </p>
          )}
        </form>
      </Sheet>

      <Sheet
        open={columnsOpen}
        onOpenChange={setColumnsOpen}
        title="Colonnes"
        description="Ajoutez, renommez ou déplacez les cases, comme dans Excel."
        footer={
          <form onSubmit={addColumn} className="flex flex-col gap-2">
            <p className="text-sm font-medium">Nouvelle colonne</p>
            <input
              value={newLabel}
              onChange={(event) => setNewLabel(event.target.value)}
              placeholder="Ex. Email, SIRET, Montant dû"
              aria-label="Nom de la nouvelle colonne"
              className={inputClass}
            />
            <div className="flex gap-2">
              <select
                value={newType}
                onChange={(event) => setNewType(event.target.value as FieldType)}
                aria-label="Type de colonne"
                className={cn(inputClass, "min-w-0 flex-1")}
              >
                {TYPES.map((type) => (
                  <option key={type} value={type}>
                    {FIELD_TYPE_LABEL[type]}
                  </option>
                ))}
              </select>
              <button type="submit" className={btnPrimary}>
                <Plus className="size-4" />
                Ajouter
              </button>
            </div>
          </form>
        }
      >
        <div className="flex flex-col gap-2 overflow-y-auto px-5 py-4">
          {data.fields.map((field, index) => (
            <div key={field.id} className="flex items-center gap-2 rounded-xl border border-line bg-bg px-2 py-2">
              <div className="min-w-0 flex-1">
                <input
                  aria-label={`Nom de la colonne ${field.label}`}
                  value={labelDraft[field.id] ?? field.label}
                  onChange={(event) => setLabelDraft((current) => ({ ...current, [field.id]: event.target.value }))}
                  onBlur={() => {
                    const next = (labelDraft[field.id] ?? field.label).trim();
                    if (next) renameField(field.id, next);
                    else setLabelDraft((current) => ({ ...current, [field.id]: field.label }));
                  }}
                  className={cn(inputClass, "h-10 bg-surface")}
                />
                <p className="mt-1 px-1 text-xs text-muted">
                  {FIELD_TYPE_LABEL[field.type]}
                  {field.builtin ? " · colonne d'origine" : ""}
                </p>
              </div>
              <button type="button" className={iconGhost} aria-label="Monter" disabled={index === 0} onClick={() => moveField(field.id, -1)}>
                <ChevronUp className="size-4" />
              </button>
              <button type="button" className={iconGhost} aria-label="Descendre" disabled={index === data.fields.length - 1} onClick={() => moveField(field.id, 1)}>
                <ChevronDown className="size-4" />
              </button>
              {!field.builtin && (
                <button
                  type="button"
                  className={iconGhost}
                  aria-label={`Supprimer la colonne ${field.label}`}
                  onClick={() =>
                    setConfirm({
                      title: `Supprimer « ${field.label} » ?`,
                      body: "Les valeurs de cette colonne seront effacées pour tous les clients.",
                      confirmLabel: "Supprimer la colonne",
                      run: () => {
                        removeField(field.id);
                        setNotice(`Colonne « ${field.label} » supprimée.`);
                      },
                    })
                  }
                >
                  <Trash2 className="size-4" />
                </button>
              )}
            </div>
          ))}
        </div>
      </Sheet>

      <AlertDialog.Root open={confirm !== null} onOpenChange={(open) => { if (!open) setConfirm(null); }}>
        <AlertDialog.Portal>
          <AlertDialog.Overlay className="fixed inset-0 z-50 bg-overlay" />
          <AlertDialog.Content className="fixed inset-x-4 top-1/2 z-50 mx-auto max-w-md -translate-y-1/2 rounded-2xl border border-line bg-surface p-5 shadow-lg">
            <AlertDialog.Title className="font-display text-2xl">{confirm?.title}</AlertDialog.Title>
            <AlertDialog.Description className="mt-2 text-sm text-pretty text-muted">
              {confirm?.body}
            </AlertDialog.Description>
            <div className="mt-5 flex justify-end gap-2">
              <AlertDialog.Cancel className={btnSurface}>Annuler</AlertDialog.Cancel>
              <AlertDialog.Action
                className={cn(btnPrimary, "bg-danger")}
                onClick={() => confirm?.run()}
              >
                {confirm?.confirmLabel}
              </AlertDialog.Action>
            </div>
          </AlertDialog.Content>
        </AlertDialog.Portal>
      </AlertDialog.Root>
    </div>
  );
}

function bucket(client: Client, today: string | null) {
  const kind = dueInfo(client.values.echeance ?? "", today).kind;
  if (kind === "late") return "late";
  if (kind === "today" || kind === "soon") return "week";
  if (kind === "empty" || kind === "bad") return "empty";
  return "later";
}

function ClientGroup({
  title,
  clients,
  fields,
  today,
  onEdit,
  onDelete,
}: {
  title: string;
  clients: Client[];
  fields: Field[];
  today: string | null;
  onEdit: (client: Client) => void;
  onDelete: (client: Client) => void;
}) {
  if (clients.length === 0) return null;
  return (
    <section>
      <h2 className="mb-2 text-sm font-semibold text-muted">
        {title} <span className="tabular-nums">· {clients.length}</span>
      </h2>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {clients.map((client) => (
          <ClientCard key={client.id} client={client} fields={fields} today={today} onEdit={onEdit} onDelete={onDelete} />
        ))}
      </div>
    </section>
  );
}

function ClientCard({
  client,
  fields,
  today,
  onEdit,
  onDelete,
}: {
  client: Client;
  fields: Field[];
  today: string | null;
  onEdit: (client: Client) => void;
  onDelete: (client: Client) => void;
}) {
  const info = dueInfo(client.values.echeance ?? "", today);
  const phone = client.values.telephone ?? "";
  const address = client.values.adresse ?? "";
  const href = telHref(phone);
  const extras = fields.filter((field) => !field.builtin && (client.values[field.id] ?? "").trim());
  return (
    <article className={cn("rounded-2xl border bg-surface p-4", info.kind === "late" ? "border-danger/40" : "border-line")}>
      <div className="flex items-start gap-2">
        <h3 className="min-w-0 flex-1 font-display text-2xl leading-tight">{clientTitle(client.values)}</h3>
        <button type="button" className={iconGhost} aria-label={`Modifier ${clientTitle(client.values)}`} onClick={() => onEdit(client)}>
          <Pencil className="size-4" />
        </button>
        <button type="button" className={iconGhost} aria-label={`Supprimer ${clientTitle(client.values)}`} onClick={() => onDelete(client)}>
          <Trash2 className="size-4" />
        </button>
      </div>
      <DueText info={info} large />
      {href && (
        <a href={href} className="mt-3 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-primary">
          <Phone className="size-4 shrink-0" />
          {phone}
        </a>
      )}
      {address && (
        <a
          href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`}
          target="_blank"
          rel="noreferrer"
          className="mt-1 flex items-start gap-2 text-sm"
        >
          <MapPin className="mt-0.5 size-4 shrink-0 text-muted" />
          <span className="break-words">{address}</span>
        </a>
      )}
      {extras.length > 0 && (
        <dl className="mt-3 grid gap-2 border-t border-line pt-3">
          {extras.map((field) => (
            <div key={field.id}>
              <dt className="text-xs text-muted">{field.label}</dt>
              <dd className={cn("text-sm break-words", field.type === "note" && "line-clamp-4 whitespace-pre-wrap", field.type === "number" && "tabular-nums")}>
                {formatFieldValue(field, client.values[field.id] ?? "")}
              </dd>
            </div>
          ))}
        </dl>
      )}
    </article>
  );
}

function DueText({ info, large = false }: { info: DueKind; large?: boolean }) {
  if (info.kind === "empty") {
    return <p className={cn("mt-2 text-muted", large ? "text-sm" : "text-sm")}>Sans échéance</p>;
  }
  const tone =
    info.kind === "late" ? "text-danger" : info.kind === "today" || info.kind === "soon" ? "text-warn" : "text-ink";
  return (
    <p className={cn("mt-2 flex items-start gap-1.5 font-semibold", large ? "text-base" : "text-sm", tone)}>
      <CalendarClock className="mt-0.5 size-4 shrink-0" />
      <span>
        {dueLabel(info)}
        {info.kind !== "later" && info.kind !== "bad" && (
          <span className="font-medium text-muted"> · {info.label}</span>
        )}
      </span>
    </p>
  );
}

function EmptyState({
  onCreate,
  onExamples,
  onImport,
  compact = false,
}: {
  onCreate: () => void;
  onExamples: () => void;
  onImport: () => void;
  compact?: boolean;
}) {
  return (
    <div className={cn("mx-auto max-w-lg text-center", !compact && "rounded-2xl border border-dashed border-line bg-surface px-5 py-10")}>
      <p className="font-display text-3xl">Aucune fiche</p>
      <p className="mt-2 text-sm text-pretty text-muted">
        Notez un client avec son nom, son téléphone, son adresse et la date d'échéance. Ajoutez ensuite d'autres colonnes — email, montant, notes — comme dans Excel.
      </p>
      <div className="mt-5 flex flex-col items-stretch justify-center gap-2 sm:flex-row sm:flex-wrap">
        <button type="button" className={btnPrimary} onClick={onCreate}>
          <Plus className="size-4" />
          Nouveau client
        </button>
        <button type="button" className={btnSurface} onClick={onImport}>
          <Upload className="size-4" />
          Importer
        </button>
        <button type="button" className={btnSurface} onClick={onExamples}>
          Voir un exemple
        </button>
      </div>
    </div>
  );
}

function NoResults({ onReset }: { onReset: () => void }) {
  return (
    <div className="rounded-2xl border border-dashed border-line bg-surface px-5 py-10 text-center">
      <p className="font-display text-2xl">Aucun résultat</p>
      <button type="button" className={cn(btnSurface, "mt-4")} onClick={onReset}>
        Réinitialiser la recherche
      </button>
    </div>
  );
}

function StatChip({
  label,
  count,
  active,
  tone,
  onClick,
}: {
  label: string;
  count: number;
  active: boolean;
  tone?: "danger" | "warn";
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        "rounded-2xl border px-2 py-3 text-center transition-colors duration-200",
        active ? "border-primary bg-primary text-primary-fg" : "border-line bg-surface text-ink",
      )}
    >
      <span
        className={cn(
          "block text-xl font-semibold tabular-nums",
          !active && tone === "danger" && count > 0 && "text-danger",
          !active && tone === "warn" && count > 0 && "text-warn",
        )}
      >
        {count}
      </span>
      <span className="block text-xs font-medium">{label}</span>
    </button>
  );
}

function FieldControl({
  field,
  value,
  onChange,
  autoFocus,
}: {
  field: Field;
  value: string;
  onChange: (value: string) => void;
  autoFocus?: boolean;
}) {
  if (field.type === "note") {
    return (
      <textarea
        value={value}
        autoFocus={autoFocus}
        rows={3}
        onChange={(event) => onChange(event.target.value)}
        className={cn(inputClass, "h-auto py-2")}
      />
    );
  }
  if (field.type === "check") {
    return (
      <span className="flex min-h-11 items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={value === "1"}
          onChange={(event) => onChange(event.target.checked ? "1" : "")}
          className="size-4 accent-primary"
        />
        Oui
      </span>
    );
  }
  const type = field.type === "date" ? "date" : field.type === "phone" ? "tel" : "text";
  const shown = field.type === "date" && !/^\d{4}-\d{2}-\d{2}$/.test(value) ? "" : value;
  return (
    <input
      type={type}
      inputMode={field.type === "number" ? "decimal" : undefined}
      autoFocus={autoFocus}
      value={field.type === "date" ? shown : value}
      onChange={(event) => onChange(event.target.value)}
      className={inputClass}
    />
  );
}

function Sheet({
  open,
  onOpenChange,
  title,
  description,
  footer,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  footer?: ReactNode;
  children: ReactNode;
}) {
  return (
    <Drawer.Root open={open} onOpenChange={onOpenChange} shouldScaleBackground={false}>
      <Drawer.Portal>
        <Drawer.Overlay className="fixed inset-0 z-40 bg-overlay" />
        <Drawer.Content className="sheet-panel fixed inset-x-0 bottom-0 z-50 mx-auto flex w-full max-w-lg flex-col overflow-hidden rounded-t-3xl bg-surface outline-none">
          <Drawer.Handle className="mx-auto mt-3 h-1.5 w-12 shrink-0 rounded-full bg-line" />
          <div className="flex shrink-0 items-start justify-between gap-3 px-5 pt-4">
            <div>
              <Drawer.Title className="font-display text-3xl leading-none">{title}</Drawer.Title>
              <Drawer.Description className="mt-2 text-sm text-pretty text-muted">{description}</Drawer.Description>
            </div>
            <button type="button" className={iconGhost} aria-label="Fermer" onClick={() => onOpenChange(false)}>
              <X className="size-4" />
            </button>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">{children}</div>
          {footer && <div className="bar-safe shrink-0 border-t border-line px-5 pt-4">{footer}</div>}
        </Drawer.Content>
      </Drawer.Portal>
    </Drawer.Root>
  );
}

function MenuItem({ children, onSelect }: { children: ReactNode; onSelect: () => void }) {
  return (
    <DropdownMenu.Item
      onSelect={onSelect}
      className="flex cursor-pointer items-center gap-2 rounded-xl px-3 py-3 text-sm outline-none data-[highlighted]:bg-bg"
    >
      {children}
    </DropdownMenu.Item>
  );
}

function downloadText(filename: string, content: string) {
  const bridge = window.CarnetAndroid;
  if (bridge) {
    bridge.saveText(filename, content);
    return;
  }
  const blob = new Blob([content], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

const btnPrimary =
  "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-fg transition-colors duration-200 hover:bg-primary/90";
const btnSurface =
  "inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-4 text-sm font-semibold text-ink transition-colors duration-200 hover:bg-bg";
const btnInverse =
  "inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-surface px-4 text-sm font-semibold text-primary transition-colors duration-200";
const iconInverse =
  "inline-flex size-11 items-center justify-center rounded-xl border border-primary-fg/30 text-primary-fg transition-colors duration-200 hover:bg-primary-fg/10";
const iconGhost =
  "inline-flex size-11 shrink-0 items-center justify-center rounded-xl text-ink transition-colors duration-200 hover:bg-bg disabled:opacity-40";
const viewBtn =
  "inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-line bg-surface px-3 text-sm font-semibold text-ink";
const viewBtnOn = "border-primary bg-primary text-primary-fg";
const inputClass =
  "h-11 w-full rounded-xl border border-line bg-surface px-3 text-base text-ink outline-none placeholder:text-muted";
