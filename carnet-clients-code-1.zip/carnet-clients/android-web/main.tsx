import { createRoot } from "react-dom/client";
import { CarnetApp } from "/workspace/src/components/carnet-app";
import "/workspace/src/styles.css";

window.__CARNET_APK__ = true;

const root = document.getElementById("root");
if (root) createRoot(root).render(<CarnetApp />);
