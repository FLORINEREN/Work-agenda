import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  root: "/workspace/scripts/apk-web",
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { "@": "/workspace/src" },
  },
  base: "./",
  build: {
    outDir: "/tmp/carnet-apk/assets/www",
    emptyOutDir: true,
    cssCodeSplit: false,
    modulePreload: false,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
        entryFileNames: "app.js",
        assetFileNames: (info) => {
          const name = info.names?.[0] ?? "";
          if (name.endsWith(".css")) return "styles.css";
          return "[name][extname]";
        },
      },
    },
  },
});
